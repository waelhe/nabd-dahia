'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Search, Zap } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Hero() {
  const { language } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const router = useRouter();
  const isArabic = language === 'ar';

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <div className="pt-20 md:pt-24 bg-gradient-to-b from-green-100 to-white py-6 md:py-8">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col items-center text-center">
          {/* اسم التطبيق */}
          <h1 className="text-2xl md:text-3xl font-black text-emerald-800 mb-3">
            {isArabic ? 'نبض الضاحية وقدسيا' : 'Nabd Dahia & Qudsaya'}
          </h1>

          {/* شريط البحث */}
          <form onSubmit={handleSearch} className="w-full max-w-lg">
            <div className="bg-white rounded-full border border-gray-200 flex items-center px-4 py-2">
              <Search className="w-4 h-4 text-gray-400 shrink-0" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={isArabic ? 'ابحث عن خدمة، محل، طبيب...' : 'Search services, shops, doctors...'}
                className="w-full bg-transparent outline-none text-gray-700 text-sm px-3"
              />
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
