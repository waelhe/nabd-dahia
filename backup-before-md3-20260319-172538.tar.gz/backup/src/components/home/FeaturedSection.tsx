'use client';

import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselPrevious,
  CarouselNext,
} from '@/components/ui/carousel';
import {
  Heart,
  Eye,
  MapPin,
  Clock,
  ChevronLeft,
  ShoppingCart,
  Building2,
  Store,
  TrendingUp,
  Star,
  Flame,
  Sparkles,
} from 'lucide-react';

const featuredListings = [
  {
    id: 1,
    type: 'marketplace',
    title: 'iPhone 13 Pro Max - ممتاز',
    price: '8,500,000',
    currency: 'ل.س',
    image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400&auto=format',
    neighborhood: 'الجزيرة الأولى',
    timeAgo: 'منذ ساعتين',
    views: 124,
    isFeatured: true,
    isHot: true,
    condition: 'ممتاز',
  },
  {
    id: 2,
    type: 'real_estate',
    title: 'شقة 140م للبيع - الجزيرة الثانية',
    price: '450,000,000',
    currency: 'ل.س',
    image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=400&auto=format',
    neighborhood: 'الجزيرة الثانية',
    timeAgo: 'منذ يوم',
    views: 89,
    isFeatured: true,
    isHot: false,
    rooms: '4 غرف',
  },
  {
    id: 3,
    type: 'marketplace',
    title: 'غسالة سامسونج 8 كيلو',
    price: '2,800,000',
    currency: 'ل.س',
    image: 'https://images.unsplash.com/photo-1626806787461-102c1d511b14?w=400&auto=format',
    neighborhood: 'شارع النخيل',
    timeAgo: 'منذ 3 ساعات',
    views: 56,
    isFeatured: false,
    isHot: false,
    condition: 'جيد جداً',
  },
  {
    id: 4,
    type: 'real_estate',
    title: 'محل تجاري للإيجار - موقع ممتاز',
    price: '500,000',
    currency: 'ل.س/شهر',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=400&auto=format',
    neighborhood: 'الشارع الرئيسي',
    timeAgo: 'منذ يومين',
    views: 234,
    isFeatured: true,
    isHot: true,
    area: '60م²',
  },
  {
    id: 5,
    type: 'marketplace',
    title: 'أثاث غرفة نوم كاملة',
    price: '4,200,000',
    currency: 'ل.س',
    image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400&auto=format',
    neighborhood: 'الجزيرة الأولى',
    timeAgo: 'منذ 5 ساعات',
    views: 78,
    isFeatured: false,
    isHot: false,
    condition: 'جديد',
  },
];

const directoryItems = [
  {
    id: 1,
    name: 'مطعم البيت السوري',
    category: 'مطاعم',
    rating: 4.5,
    reviews: 124,
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=400&auto=format',
    neighborhood: 'الشارع الرئيسي',
    isOpen: true,
    isOpenNow: true,
  },
  {
    id: 2,
    name: 'عيادة الدكتور أحمد الأسنان',
    category: 'أطباء',
    rating: 4.8,
    reviews: 89,
    image: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=400&auto=format',
    neighborhood: 'الجزيرة الثانية',
    isOpen: true,
    isOpenNow: true,
  },
  {
    id: 3,
    name: 'صيدلية الشفاء',
    category: 'صيدليات',
    rating: 4.6,
    reviews: 156,
    image: 'https://images.unsplash.com/photo-1576602976047-174e57a47881?w=400&auto=format',
    neighborhood: 'الجزيرة الأولى',
    isOpen: true,
    isOnDuty: true,
  },
  {
    id: 4,
    name: 'مركز التجميل للسيدات',
    category: 'تجميل',
    rating: 4.9,
    reviews: 234,
    image: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?w=400&auto=format',
    neighborhood: 'شارع النخيل',
    isOpen: true,
    isOpenNow: false,
  },
];

const communityPosts = [
  {
    id: 1,
    title: 'توصيات لأفضل مدرسة تقنية في المنطقة؟',
    author: 'أحمد منصور',
    authorAvatar: 'أ',
    category: 'استفسار',
    replies: 12,
    views: 156,
    timeAgo: 'منذ ساعة',
    isHot: true,
  },
  {
    id: 2,
    title: 'مبادرة تشجير شوارع الغبيري الفرعية',
    author: 'ليلى حسن',
    authorAvatar: 'ل',
    category: 'مبادرة',
    replies: 45,
    views: 324,
    timeAgo: 'منذ 3 ساعات',
    isHot: true,
  },
  {
    id: 3,
    title: 'سؤال عن إجراءات ترخيص المحال التجارية',
    author: 'كمال درويش',
    authorAvatar: 'ك',
    category: 'استفسار',
    replies: 8,
    views: 89,
    timeAgo: 'منذ يوم',
    isHot: false,
  },
];

export function FeaturedSection() {
  return (
    <Tabs defaultValue="listings" className="w-full">
      <TabsList className="grid w-full grid-cols-3 mb-4">
        <TabsTrigger value="listings" className="text-xs md:text-sm gap-1">
          <ShoppingCart className="h-3.5 w-3.5" />
          الإعلانات
        </TabsTrigger>
        <TabsTrigger value="directory" className="text-xs md:text-sm gap-1">
          <Store className="h-3.5 w-3.5" />
          المحلات
        </TabsTrigger>
        <TabsTrigger value="community" className="text-xs md:text-sm gap-1">
          <TrendingUp className="h-3.5 w-3.5" />
          المجتمع
        </TabsTrigger>
      </TabsList>

      <TabsContent value="listings" className="mt-0">
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-amber-500" />
              إعلانات مميزة
            </CardTitle>
            <Link href="/marketplace">
              <Button variant="ghost" size="sm" className="text-primary">
                عرض الكل
                <ChevronLeft className="h-4 w-4 mr-1" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <Carousel
              opts={{
                align: 'start',
                loop: true,
              }}
              className="w-full"
            >
              <CarouselContent className="-ml-4">
                {featuredListings.map((item) => (
                  <CarouselItem key={item.id} className="pl-4 basis-1/2 md:basis-1/3">
                    <Link
                      href={`/${item.type === 'real_estate' ? 'real-estate' : 'marketplace'}/${item.id}`}
                      className="block"
                    >
                      <div className="group relative rounded-xl overflow-hidden border bg-card hover:shadow-lg transition-all">
                        {/* Image */}
                        <div className="relative h-32 bg-muted overflow-hidden">
                          <img
                            src={item.image}
                            alt={item.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                          
                          {/* Badges */}
                          <div className="absolute top-2 right-2 flex flex-col gap-1">
                            {item.isHot && (
                              <Badge className="bg-red-500 text-white text-[10px] px-2 py-0.5">
                                <Flame className="h-3 w-3 ml-0.5" />
                                ساخن
                              </Badge>
                            )}
                            {item.isFeatured && (
                              <Badge className="bg-amber-500 text-white text-[10px] px-2 py-0.5">
                                <Star className="h-3 w-3 ml-0.5" />
                                مميز
                              </Badge>
                            )}
                          </div>

                          {/* Views */}
                          <div className="absolute bottom-2 left-2 flex items-center gap-1 text-white text-xs">
                            <Eye className="h-3 w-3" />
                            {item.views}
                          </div>
                        </div>

                        {/* Content */}
                        <div className="p-3">
                          <h3 className="font-medium text-sm line-clamp-1 group-hover:text-primary transition-colors">
                            {item.title}
                          </h3>
                          <p className="text-primary font-bold text-sm mt-1">
                            {item.price} <span className="text-xs font-normal text-muted-foreground">{item.currency}</span>
                          </p>
                          <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {item.neighborhood}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {item.timeAgo}
                            </span>
                          </div>
                        </div>
                      </div>
                    </Link>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="-right-4 left-auto hidden md:flex" />
              <CarouselNext className="-left-4 right-auto hidden md:flex" />
            </Carousel>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="directory" className="mt-0">
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <Store className="h-4 w-4 text-primary" />
              محلات وخدمات مميزة
            </CardTitle>
            <Link href="/directory">
              <Button variant="ghost" size="sm" className="text-primary">
                عرض الكل
                <ChevronLeft className="h-4 w-4 mr-1" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {directoryItems.map((item) => (
                <Link key={item.id} href={`/directory/${item.id}`}>
                  <div className="group flex items-center gap-4 p-3 rounded-xl border hover:bg-muted/50 transition-colors">
                    <Avatar className="h-14 w-14 rounded-xl">
                      <AvatarImage src={item.image} alt={item.name} />
                      <AvatarFallback className="rounded-xl bg-primary/10">{item.name[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium text-sm group-hover:text-primary transition-colors">
                          {item.name}
                        </h3>
                        {item.isOnDuty && (
                          <Badge variant="destructive" className="text-xs animate-pulse">
                            مناوبة
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">{item.category}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="flex items-center gap-1 text-xs">
                          <Star className="h-3 w-3 text-amber-500 fill-amber-500" />
                          {item.rating} ({item.reviews})
                        </span>
                        <span
                          className={`text-xs flex items-center gap-1 ${
                            item.isOpenNow ? 'text-green-600' : 'text-red-500'
                          }`}
                        >
                          <span
                            className={`h-2 w-2 rounded-full ${
                              item.isOpenNow ? 'bg-green-500' : 'bg-red-500'
                            }`}
                          />
                          {item.isOpenNow ? 'مفتوح الآن' : 'مغلق'}
                        </span>
                      </div>
                    </div>
                    <ChevronLeft className="h-4 w-4 text-muted-foreground group-hover:text-primary" />
                  </div>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="community" className="mt-0">
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              أحدث المناقشات
            </CardTitle>
            <Link href="/community">
              <Button variant="ghost" size="sm" className="text-primary">
                عرض الكل
                <ChevronLeft className="h-4 w-4 mr-1" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {communityPosts.map((post) => (
                <Link key={post.id} href={`/community/${post.id}`}>
                  <div className="group p-3 rounded-xl border hover:bg-muted/50 transition-colors">
                    <div className="flex items-start gap-3">
                      <Avatar className="h-10 w-10 bg-primary/10">
                        <AvatarFallback>{post.authorAvatar}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium text-sm group-hover:text-primary transition-colors line-clamp-1">
                            {post.title}
                          </h3>
                          {post.isHot && (
                            <Flame className="h-4 w-4 text-red-500 flex-shrink-0" />
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                          <span>{post.author}</span>
                          <span>•</span>
                          <span>{post.timeAgo}</span>
                          <Badge variant="secondary" className="text-[10px]">
                            {post.category}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <span>💬</span>
                            {post.replies} رد
                          </span>
                          <span className="flex items-center gap-1">
                            <Eye className="h-3 w-3" />
                            {post.views}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
}
