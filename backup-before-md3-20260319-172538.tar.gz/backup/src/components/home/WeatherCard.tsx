'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Sun,
  Cloud,
  Wind,
  Droplets,
  Thermometer,
  Eye,
  Gauge,
  CloudRain,
  RefreshCw,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

// Weather data for Qudsaya - would normally come from an API
const weatherData = {
  current: {
    temp: 22,
    feelsLike: 21,
    condition: 'مشمس',
    icon: '☀️',
    humidity: 45,
    wind: 12,
    windDirection: 'شمالية',
    pressure: 1015,
    visibility: 10,
    uv: 6,
  },
  forecast: [
    { day: 'غداً', temp: 24, tempLow: 14, icon: '⛅', condition: 'غائم جزئياً' },
    { day: 'الثلاثاء', temp: 23, tempLow: 13, icon: '☀️', condition: 'مشمس' },
    { day: 'الأربعاء', temp: 21, tempLow: 12, icon: '🌧️', condition: 'ممطر' },
    { day: 'الخميس', temp: 20, tempLow: 11, icon: '⛅', condition: 'غائم' },
  ],
  hourly: [
    { time: '12:00', temp: 22, icon: '☀️' },
    { time: '14:00', temp: 24, icon: '☀️' },
    { time: '16:00', temp: 23, icon: '⛅' },
    { time: '18:00', temp: 21, icon: '🌤️' },
    { time: '20:00', temp: 18, icon: '🌙' },
  ],
};

export function WeatherCard() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 1500);
  };

  return (
    <Card className="overflow-hidden border-0 shadow-lg bg-gradient-to-br from-sky-500 via-blue-500 to-indigo-600 text-white">
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-white/20">
              <Sun className="h-4 w-4 text-yellow-300" />
            </div>
            <span className="text-white/90">الطقس اليوم</span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-white/80 hover:text-white hover:bg-white/10"
            onClick={handleRefresh}
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="pb-4">
        {/* Current Weather */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <span className="text-6xl">{weatherData.current.icon}</span>
            <div>
              <div className="flex items-baseline gap-1">
                <p className="text-5xl font-bold">{weatherData.current.temp}°</p>
              </div>
              <p className="text-lg text-white/80">{weatherData.current.condition}</p>
              <p className="text-sm text-white/60">
                تشعر كـ {weatherData.current.feelsLike}°
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-1.5 bg-white/10 rounded-lg px-3 py-1.5">
              <Droplets className="h-3.5 w-3.5 text-sky-200" />
              <span>{weatherData.current.humidity}%</span>
            </div>
            <div className="flex items-center gap-1.5 bg-white/10 rounded-lg px-3 py-1.5">
              <Wind className="h-3.5 w-3.5 text-sky-200" />
              <span>{weatherData.current.wind} كم/س</span>
            </div>
            <div className="flex items-center gap-1.5 bg-white/10 rounded-lg px-3 py-1.5">
              <Gauge className="h-3.5 w-3.5 text-sky-200" />
              <span>{weatherData.current.pressure}</span>
            </div>
            <div className="flex items-center gap-1.5 bg-white/10 rounded-lg px-3 py-1.5">
              <Eye className="h-3.5 w-3.5 text-sky-200" />
              <span>{weatherData.current.visibility} كم</span>
            </div>
          </div>
        </div>

        {/* Hourly Forecast */}
        <div className="mb-4 overflow-x-auto scrollbar-hide">
          <div className="flex gap-2 pb-2">
            {weatherData.hourly.map((hour, i) => (
              <div
                key={i}
                className="flex flex-col items-center min-w-[50px] bg-white/10 rounded-xl px-3 py-2"
              >
                <span className="text-xs text-white/70">{hour.time}</span>
                <span className="text-xl my-1">{hour.icon}</span>
                <span className="text-sm font-medium">{hour.temp}°</span>
              </div>
            ))}
          </div>
        </div>

        {/* Forecast */}
        <div className="grid grid-cols-4 gap-2">
          {weatherData.forecast.map((day) => (
            <div
              key={day.day}
              className="text-center p-2 bg-white/10 rounded-xl hover:bg-white/20 transition-colors cursor-pointer"
            >
              <p className="text-xs text-white/70 mb-1">{day.day}</p>
              <span className="text-2xl">{day.icon}</span>
              <p className="text-sm font-medium mt-1">{day.temp}°</p>
              <p className="text-xs text-white/60">{day.tempLow}°</p>
            </div>
          ))}
        </div>

        {/* Expand/Collapse Button */}
        <Button
          variant="ghost"
          className="w-full mt-4 text-white/70 hover:text-white hover:bg-white/10"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          {isExpanded ? (
            <>
              <ChevronUp className="h-4 w-4 ml-1" />
              إخفاء التفاصيل
            </>
          ) : (
            <>
              <ChevronDown className="h-4 w-4 ml-1" />
              تفاصيل أكثر
            </>
          )}
        </Button>

        {isExpanded && (
          <div className="mt-4 pt-4 border-t border-white/20 animate-in fade-in-0 slide-in-from-top-2 duration-200">
            {/* Additional Details */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white/10 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Wind className="h-4 w-4 text-sky-200" />
                  <span className="text-sm text-white/70">الرياح</span>
                </div>
                <p className="font-medium">{weatherData.current.windDirection}</p>
                <p className="text-xs text-white/60">اتجاه الرياح</p>
              </div>
              <div className="bg-white/10 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Sun className="h-4 w-4 text-yellow-300" />
                  <span className="text-sm text-white/70">الأشعة UV</span>
                </div>
                <p className="font-medium">{weatherData.current.uv}</p>
                <p className="text-xs text-white/60">مؤشر الأشعة</p>
              </div>
            </div>
          </div>
        )}

        {/* Location */}
        <p className="text-xs text-center text-white/50 mt-4 flex items-center justify-center gap-1">
          <span>📍</span>
          ضاحية قدسيا، ريف دمشق
        </p>
      </CardContent>
    </Card>
  );
}
