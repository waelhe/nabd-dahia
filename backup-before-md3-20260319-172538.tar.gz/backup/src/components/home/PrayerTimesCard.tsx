'use client';

import { useState, useEffect, useMemo, useSyncExternalStore } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Moon, Clock, MapPin, Calendar, ChevronLeft, Volume2, Bell } from 'lucide-react';

// Prayer times for Qudsaya
const prayerTimes = [
  { name: 'الفجر', time: '04:52', icon: '🌙', nameEn: 'Fajr' },
  { name: 'الشروق', time: '06:17', icon: '🌅', nameEn: 'Sunrise' },
  { name: 'الظهر', time: '12:42', icon: '☀️', nameEn: 'Dhuhr' },
  { name: 'العصر', time: '16:27', icon: '🌤️', nameEn: 'Asr' },
  { name: 'المغرب', time: '19:07', icon: '🌅', nameEn: 'Maghrib' },
  { name: 'العشاء', time: '20:32', icon: '🌙', nameEn: 'Isha' },
];

// Helper function to get next prayer
const getNextPrayer = (currentTime: Date) => {
  const now = currentTime.getHours() * 60 + currentTime.getMinutes();
  for (const prayer of prayerTimes) {
    const [hours, minutes] = prayer.time.split(':').map(Number);
    const prayerMinutes = hours * 60 + minutes;
    if (prayerMinutes > now) {
      return { ...prayer, timeRemaining: prayerMinutes - now };
    }
  }
  // Calculate time until first prayer tomorrow
  const fajrMinutes = 4 * 60 + 52;
  const tomorrowMinutes = 24 * 60 - now + fajrMinutes;
  return { ...prayerTimes[0], timeRemaining: tomorrowMinutes };
};

// Format time remaining
const formatTimeRemaining = (minutes: number) => {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hours > 0) {
    return `باقي ${hours} ساعة و ${mins} دقيقة`;
  }
  return `باقي ${mins} دقيقة`;
};

// Custom hook for client-side Only Rendering
const emptySubscribe = () => () => {};
const getSnapshot = () => true;
const getServerSnapshot = () => false;

export function PrayerTimesCard() {
  const isClient = useSyncExternalStore(emptySubscribe, getSnapshot, getServerSnapshot);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000); // Update Every Minute

    return () => clearInterval(timer);
  }, []);

  const nextPrayer = useMemo(() => getNextPrayer(currentTime), [currentTime]);

  // Use Default Prayer During SSR to Avoid Hydration Mismatch
  const displayPrayer = isClient ? nextPrayer : prayerTimes[0];

  return (
    <Card className="overflow-hidden border-0 shadow-lg bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-900 text-white">
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-white/10">
              <Moon className="h-4 w-4 text-indigo-300" />
            </div>
            <span className="text-white/90">مواقيت الصلاة</span>
          </div>
          <Link href="/islamic">
            <Button variant="ghost" size="sm" className="text-indigo-300 hover:text-white hover:bg-white/10">
              <ChevronLeft className="h-4 w-4" />
            </Button>
          </Link>
        </CardTitle>
      </CardHeader>
      <CardContent className="pb-4">
        {/* Hijri Date */}
        <div className="flex items-center justify-center gap-2 mb-3 text-indigo-200">
          <Calendar className="h-3.5 w-3.5" />
          <span className="text-sm">15 رمضان 1446</span>
        </div>

        {/* Next Prayer Highlight */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 mb-4 border border-white/10">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-indigo-300 mb-1">الصلاة القادمة</p>
              <div className="flex items-center gap-2">
                <span className="text-2xl">{displayPrayer.icon}</span>
                <p className="text-xl font-bold text-white">{displayPrayer.name}</p>
              </div>
            </div>
            <div className="text-left">
              <p className="text-3xl font-bold text-white">{displayPrayer.time}</p>
              {isClient && displayPrayer.timeRemaining && (
                <p className="text-xs text-indigo-300 mt-1">
                  {formatTimeRemaining(displayPrayer.timeRemaining)}
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-1 mt-2 text-xs text-indigo-300">
            <MapPin className="h-3 w-3" />
            ضاحية قدسيا، سوريا
          </div>
        </div>

        {/* All Prayer Times */}
        <div className="grid grid-cols-3 gap-2">
          {prayerTimes.map((prayer) => {
            const isNext = isClient && prayer.name === nextPrayer.name;
            return (
              <div
                key={prayer.name}
                className={`text-center p-2.5 rounded-xl transition-all ${
                  isNext
                    ? 'bg-white/20 border border-white/30 shadow-lg scale-105'
                    : 'bg-white/5 hover:bg-white/10'
                }`}
              >
                <span className="text-lg">{prayer.icon}</span>
                <p className={`text-xs font-medium mt-1 ${isNext ? 'text-white' : 'text-indigo-200'}`}>
                  {prayer.name}
                </p>
                <p className={`text-sm font-bold ${isNext ? 'text-white' : 'text-indigo-300'}`}>
                  {prayer.time}
                </p>
              </div>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div className="flex gap-2 mt-4">
          <Button
            variant="outline"
            size="sm"
            className="flex-1 bg-white/10 border-white/20 text-white hover:bg-white/20"
          >
            <Bell className="h-3.5 w-3.5 ml-1" />
            تنبيه
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="flex-1 bg-white/10 border-white/20 text-white hover:bg-white/20"
          >
            <Volume2 className="h-3.5 w-3.5 ml-1" />
            أذان
          </Button>
        </div>

        {/* Date */}
        <div className="mt-4 text-center">
          <p className="text-xs text-indigo-400">15 آذار 2025</p>
        </div>
      </CardContent>
    </Card>
  );
}
