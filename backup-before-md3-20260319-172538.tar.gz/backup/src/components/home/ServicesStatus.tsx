'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Zap,
  Droplets,
  Wifi,
  Fuel,
  CheckCircle,
  XCircle,
  AlertCircle,
  Clock,
  MapPin,
  RefreshCw,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

const services = [
  {
    id: 'electricity',
    name: 'الكهرباء',
    icon: Zap,
    status: 'partial',
    message: 'مقطوعة في الجزيرة الثالثة',
    affectedAreas: ['الجزيرة الثالثة', 'شارع النخيل'],
    lastUpdate: 'منذ 15 دقيقة',
    nextUpdate: '6:00 مساءً',
    color: 'yellow',
  },
  {
    id: 'water',
    name: 'المياه',
    icon: Droplets,
    status: 'available',
    message: 'متوفرة في جميع المناطق',
    affectedAreas: [],
    lastUpdate: 'منذ ساعة',
    nextUpdate: 'غداً صباحاً',
    color: 'blue',
  },
  {
    id: 'internet',
    name: 'الإنترنت',
    icon: Wifi,
    status: 'available',
    message: 'الخدمة مستقرة',
    affectedAreas: [],
    lastUpdate: 'منذ 30 دقيقة',
    nextUpdate: 'مستمر',
    color: 'purple',
  },
  {
    id: 'fuel',
    name: 'الوقود',
    icon: Fuel,
    status: 'available',
    message: 'متوفر في المحطات',
    affectedAreas: [],
    lastUpdate: 'منذ ساعتين',
    nextUpdate: 'مستمر',
    color: 'orange',
  },
];

const statusConfig = {
  available: {
    gradient: 'from-green-500 to-emerald-600',
    bgColor: 'bg-green-50 dark:bg-green-950/50',
    borderColor: 'border-green-200 dark:border-green-800',
    textColor: 'text-green-700 dark:text-green-400',
    icon: CheckCircle,
    label: 'متوفر',
    pulseColor: 'bg-green-500',
  },
  unavailable: {
    gradient: 'from-red-500 to-rose-600',
    bgColor: 'bg-red-50 dark:bg-red-950/50',
    borderColor: 'border-red-200 dark:border-red-800',
    textColor: 'text-red-700 dark:text-red-400',
    icon: XCircle,
    label: 'غير متوفر',
    pulseColor: 'bg-red-500',
  },
  partial: {
    gradient: 'from-yellow-500 to-amber-600',
    bgColor: 'bg-yellow-50 dark:bg-yellow-950/50',
    borderColor: 'border-yellow-200 dark:border-yellow-800',
    textColor: 'text-yellow-700 dark:text-yellow-400',
    icon: AlertCircle,
    label: 'جزئي',
    pulseColor: 'bg-yellow-500',
  },
  maintenance: {
    gradient: 'from-orange-500 to-red-600',
    bgColor: 'bg-orange-50 dark:bg-orange-950/50',
    borderColor: 'border-orange-200 dark:border-orange-800',
    textColor: 'text-orange-700 dark:text-orange-400',
    icon: AlertCircle,
    label: 'صيانة',
    pulseColor: 'bg-orange-500',
  },
};

export function ServicesStatus() {
  const [expandedService, setExpandedService] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 2000);
  };

  return (
    <section className="container px-4 py-4">
      <Card className="overflow-hidden border-0 shadow-lg bg-gradient-to-br from-card to-muted/30">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              <div className="relative">
                <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
                <div className="h-2 w-2 rounded-full bg-primary absolute top-0 animate-ping" />
              </div>
              حالة الخدمات اليوم
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              className="text-xs gap-1"
              onClick={handleRefresh}
              disabled={isRefreshing}
            >
              <RefreshCw className={`h-3 w-3 ${isRefreshing ? 'animate-spin' : ''}`} />
              تحديث
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {services.map((service) => {
              const config = statusConfig[service.status as keyof typeof statusConfig];
              const Icon = service.icon;
              const StatusIcon = config.icon;
              const isExpanded = expandedService === service.id;

              return (
                <div
                  key={service.id}
                  className={`rounded-xl ${config.bgColor} border ${config.borderColor} transition-all duration-300 overflow-hidden ${
                    isExpanded ? 'col-span-2 md:col-span-2' : ''
                  }`}
                >
                  <div
                    className="p-3 cursor-pointer"
                    onClick={() => setExpandedService(isExpanded ? null : service.id)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="p-2.5 rounded-xl bg-background shadow-sm">
                        <Icon className={`h-5 w-5 ${config.textColor}`} />
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge
                          className={`text-xs bg-gradient-to-r ${config.gradient} text-white border-0`}
                        >
                          {config.label}
                        </Badge>
                        <div className={`h-2 w-2 rounded-full ${config.pulseColor} animate-pulse`} />
                      </div>
                    </div>
                    <h3 className="font-semibold mb-1">{service.name}</h3>
                    <p className="text-xs text-muted-foreground line-clamp-1">
                      {service.message}
                    </p>

                    {isExpanded && (
                      <div className="mt-4 pt-4 border-t border-border/50 animate-in fade-in-0 duration-200">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-muted-foreground text-xs mb-1">آخر تحديث</p>
                            <p className="font-medium flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {service.lastUpdate}
                            </p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs mb-1">التحديث القادم</p>
                            <p className="font-medium">{service.nextUpdate}</p>
                          </div>
                        </div>

                        {service.affectedAreas.length > 0 && (
                          <div className="mt-4">
                            <p className="text-muted-foreground text-xs mb-2 flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              المناطق المتأثرة:
                            </p>
                            <div className="flex flex-wrap gap-1.5">
                              {service.affectedAreas.map((area) => (
                                <span
                                  key={area}
                                  className="text-xs px-2.5 py-1 bg-background rounded-full border shadow-sm"
                                >
                                  {area}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full mt-4"
                        >
                          عرض التفاصيل
                        </Button>
                      </div>
                    )}

                    {service.affectedAreas.length > 0 && !isExpanded && (
                      <div className="mt-2 flex items-center justify-between">
                        <div className="flex -space-x-1 rtl:space-x-reverse">
                          {service.affectedAreas.slice(0, 2).map((area, i) => (
                            <span
                              key={area}
                              className="text-xs px-2 py-0.5 bg-background rounded-full border text-[10px]"
                            >
                              {area}
                            </span>
                          ))}
                        </div>
                        <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Stats */}
          <div className="mt-4 pt-4 border-t flex items-center justify-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-green-500" />
              <span className="text-muted-foreground">متوفر</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-yellow-500" />
              <span className="text-muted-foreground">جزئي</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-red-500" />
              <span className="text-muted-foreground">غير متوفر</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
