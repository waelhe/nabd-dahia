'use client';

import Link from 'next/link';
import { Badge } from '@/components/ui/badge';

const newsItems = [
  {
    id: 1,
    type: 'urgent',
    label: 'عاجل',
    message: 'انقطاع الكهرباء في الجزيرة الثالثة حتى الساعة 6 مساءً',
    color: 'bg-red-500',
    textColor: 'text-red-500',
  },
  {
    id: 2,
    type: 'announcement',
    label: 'إعلان',
    message: 'البلدية: بدء أعمال تعبيد شارع النخيل الأسبوع القادم',
    color: 'bg-primary',
    textColor: 'text-primary',
  },
  {
    id: 3,
    type: 'event',
    label: 'فعالية',
    message: 'معرض العائلة السورية يوم الجمعة في مجمع الضاحية',
    color: 'bg-purple-500',
    textColor: 'text-purple-500',
  },
  {
    id: 4,
    type: 'new',
    label: 'جديد',
    message: 'افتتاح فرع جديد لسوق التوفير قرب الجامع الكبير',
    color: 'bg-cyan-500',
    textColor: 'text-cyan-500',
  },
];

export function NewsMarquee() {
  return (
    <section className="bg-gradient-to-r from-muted/50 via-muted/80 to-muted/50 border-y">
      <div className="container px-4 py-3">
        <div className="overflow-hidden">
          <div className="flex items-center gap-8 animate-marquee whitespace-nowrap">
            {[...newsItems, ...newsItems].map((item, index) => (
              <div key={`${item.id}-${index}`} className="flex items-center gap-3">
                <Badge
                  className={`${item.color} text-white text-xs font-bold gap-1 shrink-0`}
                >
                  {item.type === 'urgent' && '⚠️'}
                  {item.type === 'announcement' && '📢'}
                  {item.type === 'event' && '📅'}
                  {item.type === 'new' && 'ℹ️'}
                  {item.label}
                </Badge>
                <Link
                  href={`/news/${item.id}`}
                  className="text-sm hover:text-primary transition-colors cursor-pointer"
                >
                  {item.message}
                </Link>
                <span className="text-muted-foreground mx-4">•</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
