'use client';

import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Phone,
  Flame,
  Siren,
  Heart,
  Zap,
  Droplets,
  Shield,
  Building2,
  Wrench,
  PhoneCall,
} from 'lucide-react';

const emergencyContacts = [
  { 
    name: 'الإسعاف', 
    number: '110', 
    icon: Heart, 
    color: 'text-red-500',
    bgColor: 'bg-red-500/10',
    available: true,
  },
  { 
    name: 'الإطفاء', 
    number: '113', 
    icon: Flame, 
    color: 'text-orange-500',
    bgColor: 'bg-orange-500/10',
    available: true,
  },
  { 
    name: 'الشرطة', 
    number: '112', 
    icon: Shield, 
    color: 'text-blue-500',
    bgColor: 'bg-blue-500/10',
    available: true,
  },
  { 
    name: 'الكهرباء', 
    number: '115', 
    icon: Zap, 
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-500/10',
    available: true,
  },
  { 
    name: 'المياه', 
    number: '117', 
    icon: Droplets, 
    color: 'text-cyan-500',
    bgColor: 'bg-cyan-500/10',
    available: true,
  },
  { 
    name: 'البلدية', 
    number: '119', 
    icon: Building2, 
    color: 'text-emerald-500',
    bgColor: 'bg-emerald-500/10',
    available: true,
  },
  { 
    name: 'الصيانة', 
    number: '121', 
    icon: Wrench, 
    color: 'text-purple-500',
    bgColor: 'bg-purple-500/10',
    available: false,
  },
];

export function EmergencyContacts() {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-red-500/10">
            <Siren className="h-4 w-4 text-red-500" />
          </div>
          <span>أرقام الطوارئ</span>
          <Badge variant="secondary" className="mr-auto text-xs">
            24/7
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {emergencyContacts.map((contact) => {
            const Icon = contact.icon;
            return (
              <a
                key={contact.name}
                href={`tel:${contact.number}`}
                className="flex items-center justify-between p-3 rounded-xl hover:bg-muted transition-all group border border-transparent hover:border-border"
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-xl ${contact.bgColor} group-hover:scale-110 transition-transform`}>
                    <Icon className={`h-4 w-4 ${contact.color}`} />
                  </div>
                  <div>
                    <span className="text-sm font-medium group-hover:text-primary transition-colors">
                      {contact.name}
                    </span>
                    <p className="text-xs text-muted-foreground">
                      {contact.available ? 'متاح الآن' : 'غير متاح'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-lg text-primary">{contact.number}</span>
                  <PhoneCall className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
              </a>
            );
          })}
        </div>

        <Link href="/directory?category=emergency" className="block mt-4">
          <Button variant="outline" className="w-full hover:bg-primary hover:text-primary-foreground transition-colors">
            <Phone className="h-4 w-4 ml-2" />
            جميع أرقام الطوارئ
          </Button>
        </Link>

        {/* Quick Tip */}
        <div className="mt-4 p-3 bg-muted/50 rounded-xl">
          <p className="text-xs text-muted-foreground text-center">
            💡 نصيحة: احفظ هذه الأرقام في هاتفك للوصول السريع
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
