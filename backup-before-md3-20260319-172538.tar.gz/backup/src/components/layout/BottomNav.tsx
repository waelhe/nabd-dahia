'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Home,
  ShoppingCart,
  Building2,
  BookOpen,
  Users,
  Menu,
  Plus,
} from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { TrendingUp, Moon, PlusCircle, Heart, User, Settings, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

const mainNavItems = [
  { href: '/', label: 'الرئيسية', icon: Home },
  { href: '/marketplace', label: 'السوق', icon: ShoppingCart },
  { href: '/real-estate', label: 'العقارات', icon: Building2 },
  { href: '/directory', label: 'الدليل', icon: BookOpen },
  { href: '/community', label: 'المجتمع', icon: Users },
];

const moreNavItems = [
  { href: '/market-prices', label: 'أسعار السوق', icon: TrendingUp, color: 'bg-cyan-500' },
  { href: '/islamic', label: 'مواقيت الصلاة', icon: Moon, color: 'bg-indigo-500' },
  { href: '/marketplace?new=true', label: 'أضف إعلان', icon: PlusCircle, color: 'bg-primary' },
  { href: '/favorites', label: 'المفضلة', icon: Heart, color: 'bg-rose-500' },
  { href: '/profile', label: 'حسابي', icon: User, color: 'bg-slate-500' },
  { href: '/settings', label: 'الإعدادات', icon: Settings, color: 'bg-slate-600' },
];

export function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-lg border-t border-border/50 safe-area-bottom">
      <div className="flex items-center justify-around h-16 px-2">
        {/* Add Button - Center */}
        <Link
          href="/marketplace?new=true"
          className="flex flex-col items-center justify-center w-14 h-14 -mt-6 rounded-full bg-primary text-primary-foreground shadow-lg hover:scale-105 transition-transform"
        >
          <Plus className="h-6 w-6" />
        </Link>

        {mainNavItems.slice(0, 4).map((item) => {
          const isActive = pathname === item.href;
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center justify-center w-full h-full transition-all ${
                isActive
                  ? 'text-primary'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <div className={`relative ${isActive ? 'scale-110' : ''} transition-transform`}>
                <Icon className="h-5 w-5" />
                {isActive && (
                  <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary" />
                )}
              </div>
              <span className="text-xs mt-1 font-medium">{item.label}</span>
            </Link>
          );
        })}

        {/* More Menu */}
        <Sheet>
          <SheetTrigger asChild>
            <button className="flex flex-col items-center justify-center w-full h-full text-muted-foreground hover:text-foreground transition-colors">
              <Menu className="h-5 w-5" />
              <span className="text-xs mt-1 font-medium">المزيد</span>
            </button>
          </SheetTrigger>
          <SheetContent side="bottom" className="h-[70vh] rounded-t-3xl px-6">
            <SheetHeader>
              <SheetTitle className="text-center flex items-center justify-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" />
                المزيد
              </SheetTitle>
            </SheetHeader>
            
            <div className="mt-6">
              {/* Quick Add Button */}
              <Link href="/marketplace?new=true" className="block mb-6">
                <Button className="w-full h-14 text-lg rounded-2xl bg-gradient-to-r from-primary to-emerald-600 hover:opacity-90 shadow-lg">
                  <PlusCircle className="h-5 w-5 ml-2" />
                  أضف إعلانك مجاناً
                </Button>
              </Link>

              <div className="grid grid-cols-3 gap-4">
                {moreNavItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="flex flex-col items-center justify-center gap-3 p-4 rounded-2xl bg-muted/50 hover:bg-muted transition-colors group"
                    >
                      <div className={`h-14 w-14 rounded-2xl ${item.color} flex items-center justify-center shadow-md group-hover:scale-110 transition-transform`}>
                        <Icon className="h-7 w-7 text-white" />
                      </div>
                      <span className="text-sm font-medium">{item.label}</span>
                    </Link>
                  );
                })}
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </nav>
  );
}
