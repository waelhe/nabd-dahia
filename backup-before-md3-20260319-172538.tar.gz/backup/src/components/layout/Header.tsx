'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Menu,
  Search,
  Sun,
  Moon,
  User,
  Home,
  ShoppingCart,
  Building2,
  BookOpen,
  Users,
  TrendingUp,
  Moon as MoonIcon,
  Settings,
  LogIn,
  PlusCircle,
  Heart,
  MessageSquare,
  LayoutDashboard,
  Sparkles,
} from 'lucide-react';
import { useTheme } from 'next-themes';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { NotificationBell } from '@/components/notifications/NotificationBell';
import { Badge } from '@/components/ui/badge';

const navLinks = [
  { href: '/', label: 'الرئيسية', icon: Home },
  { href: '/marketplace', label: 'السوق', icon: ShoppingCart },
  { href: '/real-estate', label: 'العقارات', icon: Building2 },
  { href: '/directory', label: 'الدليل', icon: BookOpen },
  { href: '/community', label: 'المجتمع', icon: Users },
  { href: '/market-prices', label: 'الأسعار', icon: TrendingUp },
  { href: '/islamic', label: 'إسلامي', icon: MoonIcon },
];

export function Header() {
  const { theme, setTheme } = useTheme();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-xl supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center px-4 gap-2">
        {/* Mobile Menu */}
        <Sheet>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon" className="shrink-0">
              <Menu className="h-5 w-5" />
              <span className="sr-only">فتح القائمة</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-80">
            <SheetHeader>
              <SheetTitle className="text-right flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" />
                القائمة
              </SheetTitle>
            </SheetHeader>
            <nav className="flex flex-col gap-1 mt-6">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-muted transition-colors group"
                >
                  <div className="p-2 rounded-lg bg-muted group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    <link.icon className="h-4 w-4" />
                  </div>
                  <span className="font-medium">{link.label}</span>
                </Link>
              ))}
              <div className="border-t my-4" />
              {!isLoggedIn ? (
                <>
                  <Link
                    href="/auth/login"
                    className="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-muted transition-colors"
                  >
                    <LogIn className="h-5 w-5 text-primary" />
                    <span className="font-medium">تسجيل الدخول</span>
                  </Link>
                  <Link
                    href="/auth/register"
                    className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 transition-colors mt-2"
                  >
                    <PlusCircle className="h-5 w-5" />
                    <span className="font-medium">إنشاء حساب</span>
                  </Link>
                </>
              ) : (
                <>
                  <Link
                    href="/dashboard"
                    className="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-muted transition-colors"
                  >
                    <LayoutDashboard className="h-5 w-5 text-primary" />
                    <span className="font-medium">لوحة التحكم</span>
                  </Link>
                  <Link
                    href="/favorites"
                    className="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-muted transition-colors"
                  >
                    <Heart className="h-5 w-5 text-primary" />
                    <span className="font-medium">المفضلة</span>
                  </Link>
                  <Link
                    href="/messages"
                    className="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-muted transition-colors"
                  >
                    <MessageSquare className="h-5 w-5 text-primary" />
                    <span className="font-medium">الرسائل</span>
                  </Link>
                  <Link
                    href="/settings"
                    className="flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-muted transition-colors"
                  >
                    <Settings className="h-5 w-5 text-primary" />
                    <span className="font-medium">الإعدادات</span>
                  </Link>
                </>
              )}
            </nav>
          </SheetContent>
        </Sheet>

        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 shrink-0 group">
          <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-primary to-emerald-600 flex items-center justify-center shadow-md group-hover:scale-105 transition-transform">
            <span className="text-primary-foreground font-bold text-lg">ق</span>
          </div>
          <span className="font-bold text-lg hidden sm:inline-block bg-gradient-to-l from-primary to-emerald-600 bg-clip-text text-transparent">
            قدسيا بلس
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-1 flex-1">
          {navLinks.slice(0, 5).map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="px-3 py-2 text-sm font-medium rounded-lg hover:bg-muted hover:text-primary transition-colors"
            >
              {link.label}
            </Link>
          ))}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="gap-1">
                المزيد
                <Badge variant="secondary" className="ml-1 text-[10px] px-1">2</Badge>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-48">
              {navLinks.slice(5).map((link) => (
                <DropdownMenuItem key={link.href} asChild>
                  <Link href={link.href} className="flex items-center gap-2 cursor-pointer">
                    <link.icon className="h-4 w-4 text-primary" />
                    {link.label}
                  </Link>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>

        {/* Search Dialog */}
        <Dialog>
          <DialogTrigger asChild>
            <Button variant="ghost" size="icon" className="shrink-0">
              <Search className="h-5 w-5" />
              <span className="sr-only">بحث</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Search className="h-4 w-4" />
                البحث في المنصة
              </DialogTitle>
            </DialogHeader>
            <div className="relative mt-4">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="ابحث عن منتج، عقار، محل..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10 h-12"
              />
            </div>
            <div className="mt-4">
              <p className="text-sm text-muted-foreground mb-3 flex items-center gap-1">
                <Sparkles className="h-3 w-3" />
                بحث سريع:
              </p>
              <div className="flex flex-wrap gap-2">
                {['شقة للإيجار', 'سيارة مستعملة', 'صيدلية مناوبة', 'طبيب أسنان'].map(
                  (term) => (
                    <Button
                      key={term}
                      variant="outline"
                      size="sm"
                      onClick={() => setSearchQuery(term)}
                      className="hover:bg-primary hover:text-primary-foreground"
                    >
                      {term}
                    </Button>
                  )
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Actions */}
        <div className="flex items-center gap-1">
          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="shrink-0"
          >
            <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">تبديل الوضع</span>
          </Button>

          {/* Notifications */}
          <NotificationBell />

          {/* User Menu */}
          {isLoggedIn ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full shrink-0">
                  <Avatar className="h-8 w-8 ring-2 ring-primary/20">
                    <AvatarImage src="/avatar.png" alt="المستخدم" />
                    <AvatarFallback className="bg-primary/10 text-primary">م</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                <DropdownMenuItem asChild>
                  <Link href="/profile" className="flex items-center gap-2 cursor-pointer">
                    <User className="h-4 w-4" />
                    الملف الشخصي
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/my-listings" className="flex items-center gap-2 cursor-pointer">
                    <PlusCircle className="h-4 w-4" />
                    إعلاناتي
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/favorites" className="flex items-center gap-2 cursor-pointer">
                    <Heart className="h-4 w-4" />
                    المفضلة
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/admin" className="flex items-center gap-2 cursor-pointer">
                    <LayoutDashboard className="h-4 w-4" />
                    لوحة الإدارة
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => setIsLoggedIn(false)}
                  className="text-destructive focus:text-destructive cursor-pointer"
                >
                  <LogIn className="h-4 w-4 ml-2" />
                  تسجيل الخروج
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button size="sm" className="hidden sm:flex gap-2 bg-gradient-to-r from-primary to-emerald-600 hover:opacity-90">
              <LogIn className="h-4 w-4" />
              دخول
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
