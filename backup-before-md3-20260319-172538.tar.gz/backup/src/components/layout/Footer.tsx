'use client';

import Link from 'next/link';
import {
  Facebook,
  Instagram,
  Twitter,
  Phone,
  Mail,
  MapPin,
  Heart,
  MessageCircle,
  Sparkles,
} from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';

const quickLinks = [
  { href: '/marketplace', label: 'سوق المستعمل' },
  { href: '/real-estate', label: 'العقارات' },
  { href: '/directory', label: 'دليل الفعاليات' },
  { href: '/community', label: 'منتدى المجتمع' },
];

const serviceLinks = [
  { href: '/market-prices', label: 'أسعار السوق' },
  { href: '/islamic', label: 'مواقيت الصلاة' },
  { href: '/emergency', label: 'أرقام الطوارئ' },
  { href: '/pharmacies', label: 'الصيدليات المناوبة' },
];

export function Footer() {
  return (
    <footer className="hidden md:block bg-gradient-to-b from-muted/30 to-muted/60 border-t mt-auto">
      <div className="container px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2 group">
              <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-primary to-emerald-600 flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                <span className="text-primary-foreground font-bold text-2xl">ق</span>
              </div>
              <div>
                <span className="font-bold text-xl block">قدسيا بلس</span>
                <span className="text-xs text-muted-foreground">نبض الضاحية</span>
              </div>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              منصة خدمية اجتماعية تجارية مخصصة لسكان ضاحية قدسيا. نساعدك في العثور على
              ما تحتاجه في منطقتك.
            </p>
            <div className="flex items-center gap-3">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="h-10 w-10 rounded-xl bg-muted flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all hover:scale-110 shadow-sm"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="h-10 w-10 rounded-xl bg-muted flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all hover:scale-110 shadow-sm"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="h-10 w-10 rounded-xl bg-muted flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all hover:scale-110 shadow-sm"
              >
                <Twitter className="h-5 w-5" />
              </a>
              <a
                href="https://wa.me/963912345678"
                target="_blank"
                rel="noopener noreferrer"
                className="h-10 w-10 rounded-xl bg-muted flex items-center justify-center hover:bg-green-500 hover:text-white transition-all hover:scale-110 shadow-sm"
              >
                <MessageCircle className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              روابط سريعة
            </h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center gap-2 group"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-primary/50 group-hover:bg-primary transition-colors" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Phone className="h-4 w-4 text-primary" />
              خدمات
            </h3>
            <ul className="space-y-3">
              {serviceLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center gap-2 group"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-primary/50 group-hover:bg-primary transition-colors" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <MapPin className="h-4 w-4 text-primary" />
              تواصل معنا
            </h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 text-primary mt-0.5" />
                <span>ضاحية قدسيا، ريف دمشق<br />سوريا</span>
              </li>
              <li className="flex items-center gap-3 text-sm text-muted-foreground">
                <Phone className="h-4 w-4 text-primary" />
                <a href="tel:+963111234567" className="hover:text-primary transition-colors">
                  +963 11 123 4567
                </a>
              </li>
              <li className="flex items-center gap-3 text-sm text-muted-foreground">
                <Mail className="h-4 w-4 text-primary" />
                <a href="mailto:info@qudsayaplus.com" className="hover:text-primary transition-colors">
                  info@qudsayaplus.com
                </a>
              </li>
            </ul>

            {/* App Download Buttons */}
            <div className="mt-6 flex gap-2">
              <Button variant="outline" size="sm" className="gap-2">
                <span>📱</span>
                App Store
              </Button>
              <Button variant="outline" size="sm" className="gap-2">
                <span>📱</span>
                Google Play
              </Button>
            </div>
          </div>
        </div>

        <Separator className="my-8" />

        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>
            © {new Date().getFullYear()} قدسيا بلس. جميع الحقوق محفوظة.
          </p>
          <p className="flex items-center gap-1">
            صُنع بـ
            <Heart className="h-4 w-4 text-red-500 fill-red-500 animate-pulse" />
            في ضاحية قدسيا
          </p>
          <div className="flex items-center gap-4">
            <Link href="/privacy" className="hover:text-primary transition-colors">
              سياسة الخصوصية
            </Link>
            <Link href="/terms" className="hover:text-primary transition-colors">
              الشروط والأحكام
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
