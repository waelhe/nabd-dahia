'use client';

import { HeroSection } from '@/components/home/HeroSection';
import { ServicesStatus } from '@/components/home/ServicesStatus';
import { QuickAccess } from '@/components/home/QuickAccess';
import { NewsMarquee } from '@/components/home/NewsMarquee';
import { FeaturedSection } from '@/components/home/FeaturedSection';
import { PrayerTimesCard } from '@/components/home/PrayerTimesCard';
import { EmergencyContacts } from '@/components/home/EmergencyContacts';
import { WeatherCard } from '@/components/home/WeatherCard';

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <HeroSection />

      {/* News Ticker */}
      <NewsMarquee />

      {/* Services Status (Electricity, Water) */}
      <ServicesStatus />

      {/* Quick Access Grid */}
      <QuickAccess />

      {/* Main Content Grid */}
      <div className="container px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Featured Listings */}
            <FeaturedSection />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Prayer Times */}
            <PrayerTimesCard />

            {/* Weather */}
            <WeatherCard />

            {/* Emergency Contacts */}
            <EmergencyContacts />
          </div>
        </div>
      </div>
    </div>
  );
}
